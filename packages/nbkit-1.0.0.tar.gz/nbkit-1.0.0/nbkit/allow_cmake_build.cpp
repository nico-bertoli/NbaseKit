//needed to allow cmake build

//todo try to remove this